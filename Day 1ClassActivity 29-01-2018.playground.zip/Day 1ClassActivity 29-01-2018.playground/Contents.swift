var n = 11
if n > 10
{
    print("Multiplication Table for 5 is")
    for index in 0...10 {
        print("5*\(index) = ",5*index)
    }
}
else
{
    print("Factorial of five is : ")
    var factorial = 5
    for index in 1..<factorial
    {
        factorial = factorial * index
    }
    print("Factoral of five is:", factorial)
}
