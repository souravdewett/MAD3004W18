//
//  Product.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation

class product{
    let name:String
    
    init?(name : String)
    {
    if name.isEmpty
    {
        return nil
        }
        self.name = name
}
}
