//
//  main.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation

print("Hello, World!")

let laptop = product(name: "laptop")
if let machine = laptop
{
    print("Product name is \(machine.name)")
}
let anonymousMachine = product(name : "")
if anonymousMachine == nil
{
    print("The anonymous machine could not be initialized")
}

if let Mobile = CartItem(name: "Mobile", quantity: 0)
{
print("Cart contains \(Mobile.quantity) \(Mobile.name)")
}
else
{
    print("unable to initialize cart item")
}

var objMenu = manufacturer(name: "Audi")
print("\(objMenu.name)")

let vehicle = Vehicle(name : "BMW ")

let Preference = preferences()
//let preference = Preference(name : "BMW", noOfWheels : 2)
print(Preference?.description as Any)
