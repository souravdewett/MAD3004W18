//
//  Person.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation

class Person
{
    var firstname : String
    var lastname : String
    var Address : String
    
    init(firstname:String , lastname : String, Address: String)
    {
        self.firstname = ""
        self.lastname = ""
        self.Address = ""
    }
}
