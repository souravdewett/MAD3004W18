//
//  Preferences.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation

class preferences:Vehicle
{
    var prefer = false
    var description : String
    {
        var output = "Do you prefer \(noOfWheels) wheel vehicles from \(name)?"
        output += prefer ? "❌": "❓"
        return output
    }
}
