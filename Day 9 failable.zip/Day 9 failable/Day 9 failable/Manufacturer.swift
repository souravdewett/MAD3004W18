//
//  Manufacturer.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class manufacturer
{
    var name : String
    
    //Designated Initializer
    init(name: String)
    {
        self.name = name
    }
    
    convenience init?()
    {
        self.init(name : "[Unknown]")
    }
}
