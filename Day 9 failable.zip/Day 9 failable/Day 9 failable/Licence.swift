//
//  Licence.swift
//  Day 9 failable
//
//  Created by Sourav Dewett on 2018-02-08.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class licence
{
    var age : Int
    var location : String
    
    init?(age : Int , location : String)
    {
        self.age = 0
        self.location = ""
        if age < 16
        {
            return nil
        }
        else{
            self.age = age
            self.location = location
        }
    }

}
