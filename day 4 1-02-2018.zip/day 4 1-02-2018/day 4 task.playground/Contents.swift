//: Playground - noun: a place where people can play

//Creting Class reference for the Class person object
class AddressP
{
    var Street = "34"
    var Area = "Brampton"
    var PostalCode = "L6Y3B6"
}

//Main Class
class Person
{
    var FirstName = "Sourav"
    var LastName = "Cheema"
    var Age = 20
    var Address = AddressP()
    var TotalAmount = 2000
}

//creating object for the class Person
var object = Person()

//Accessing class members by object
object.FirstName = "Sourav";
object.LastName = "Cheema";
object.Age = 20;
object.Address.Area = "Brampton";
object.Address.PostalCode = "L8Y3B8";
object.Address.Street = "Windmill Blvd.";
object.TotalAmount = 3000;

print("FirstName: ", object.FirstName);
print("LastName: ", object.LastName);
print("Age: ", object.Age);
print("Area: ", object.Address.Area);
print("Area PostalCode: ", object.Address.PostalCode);
print("Street: ", object.Address.Street);
print("TotalAmount : ", object.TotalAmount);
