//: Playground - noun: a place where people can play
struct project{
    var title = ""
    var hours = 0

    func display()
    {
        print("Project title : ",title)
        print("Total work hours required",hours)
    }
}

//Declaring instance of structure
var LMSProject = project(title : "Moodle", hours : 200) //technologies: ["PHP", "AJAX", " JQuery"]
print(LMSProject)

LMSProject.display()

LMSProject.hours = 300
LMSProject.display()

//class declaration
class Manager
{
    var name : String = ""
    var productOwner : Bool = true
    var currentProjects = project()
}

//creating instance of a class
let mgr = Manager()
mgr.name = " Cheema"
mgr.productOwner = true
mgr.currentProjects = project(title : " sales reporting",hours:20)

print("Mgr Canada Name : ",mgr.name)
print("mgr Canada Product owner : ",mgr.productOwner)
print("Mgr Canada Current Project title : ",mgr.currentProjects.title)

//structures are value types

struct address{
    var street = "265 Yorkland Boulevard"
    var city = "North york"
    var postalCode = "M1H1y1"
}

var lambton = address()
print("lambton : ",lambton)

var cestar = lambton
//let cestar = lambton //raise error when change the parameter
print("Cestar :",cestar)

cestar.street = "271 Yorkland Boulevard"
cestar.postalCode = "M1H3Y3"
print("Cestar : ",cestar)

print("lambton : ", lambton)

//classes are REFERECES TYPES
class Institute
{
    var street = "265 Yorkland Boulevard"
    var city = "North york"
    var postalCode = "M1H1Y1"
}

var myLambton = Institute()
print("myLambotn Street : ", myLambton.street)
print("myLambton City : ", myLambton.city)
print("myLambton Postal code", myLambton.postalCode )

var myCestar = myLambton
print("myCestar Street : ", myCestar.street)
print("myCestar City : ", myCestar.city)
print("myCestar Postal code", myCestar.postalCode )

print("myLambton Street : ", myLambton.street)
print("myLambton postalcode : ", myLambton.postalCode)

//identical to ====
if myLambton === myCestar //===check whether both the objects refers to the same type
{
    print("lambton and cestar are same")
}
else
{
    print("lambton and cestar are not the same")
}

var yourCestar = Institute()
if yourCestar === myCestar
{
    print("yourCestar and mycestar are same")
}
else
{
    print("yourCestar and mycestar are not the same")
}
