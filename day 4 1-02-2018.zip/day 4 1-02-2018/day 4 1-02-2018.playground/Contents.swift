//: Playground - noun: a place where people can play

import UIKit
//sorted closure

var months = [4,3,1,6,5,2]
print(months.sorted())

func reverse(_ s1: Int, _ s2: Int) -> Bool{
    return s1 > s2
}

var reversedMonths = months.sorted(by: reverse)
print("reversedMonths",reversedMonths)

func increasing(_ s1: Int, _ s2: Int) -> Bool
{
return s1 < s2
}

var increasingMonths = months.sorted(by: increasing)
print("increasing months :",increasingMonths)

var reverseClosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})
print("reverseClosure",reverseClosure)

//inferring parameter types from context
var infertypes = months.sorted(by: {
    //(s1, s2) in return s1 < s2
    (s1 , s2) in s1 < s2 //implicit return
})
print("inferTypes:",infertypes)

//shorthand argument names
print("shorthand argument : ",months.sorted(by: {$0 < $1}))

//operator methods
print("operator methods : ",months.sorted(by: <))

var three = [1,3,4,5,6,7,8,9,12,15]
print("three : ", three)

var modthree = three.filter({ $0 % 3 == 0})
print("modThree : ", modthree)

var even = [12,14,16,13,15,17]
print("Even : ",even)

var eventwo = even.filter({$0 % 2 == 0})
print("Even : ",eventwo)

//nested functions closure
func makeIncrementer(forIncrement amount: Int) -> () -> Int {
    var runningtotal = 0
    
    func incrementer() -> Int{
        runningtotal += amount
        return runningtotal
    }
    return incrementer
}

let incrementByTen = makeIncrementer(forIncrement: 10)

print("First Call", incrementByTen())   //10
print("Second Call", incrementByTen())  //20
print("Third Call", incrementByTen())   //30
print("Fourth Call", incrementByTen())  //40

//instance of a function
let incrementBySeven = makeIncrementer(forIncrement: 7)
print("Increment by Seven 1 : ", incrementBySeven())
print("Increment by Seven 2 : ", incrementBySeven())

//closures are reference type
let incrementBysevenagain = incrementBySeven
print("increment by seven 3 : ", incrementBysevenagain())

//AutoClosures
var errorList = [404,414,402,431,455,440]
print("Total Errors : ",errorList.count)

let debugger = {errorList.remove(at:0)}
print("Total Errors : ", errorList.count)

print("Now Solving \(debugger())!")
print("Total errors: ",errorList.count)
print("Error List :",errorList)

func solve(error debugger: @autoclosure () -> Int)
{
    print("Now Solving \(debugger())!")
}

solve(error: errorList.remove(at:0))
print("ErrorList : ",errorList)

