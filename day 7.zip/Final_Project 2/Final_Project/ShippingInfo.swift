//
//  ShippingInfo.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class ShippingInfo: Order{
    
    var shippingType : String?
    var shippingCost : Int?
    // var shippingRegion : String? ///////new var///
    var shippingRegionID : Int?
    
    //intializer
    override init(){
        super.init()
        self.shippingType = ""
        self.shippingCost = 0
        //self.shippingRegion = ""
        self.shippingRegionID = 0
        
    }
    //parameterized initializer
    init(o_shippingId: String,s_shippingType: String,s_shippingCost: Int,s_shippingRegionId: Int){
        super.init()
        self.shippingType = s_shippingType
        self.shippingCost = s_shippingCost
        self.shippingRegionID = s_shippingRegionId
        
    }
    
    func updateShippingInfo(){
        
    }
    
}
