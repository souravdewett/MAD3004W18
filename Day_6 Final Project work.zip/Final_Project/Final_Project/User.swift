//
//  User.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class User{
    var userID : String?
    var password : String?
    var logInStatus : String?
    
    //initializers
    init(){
        
        self.userID = ""
        self.password = ""
        self.logInStatus = ""
        
    }
    //parameterized initializer
    
    init(u_Id: String, u_pwd: String, u_loginstatus: String){
        
        self.userID = u_Id
        self.password = u_pwd
        self.logInStatus = u_loginstatus
        
    }
    
    func verifyLogin(){
        
    }
    
}
