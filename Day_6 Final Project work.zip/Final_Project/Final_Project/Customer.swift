//
//  Customer.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class Customer: User{
    var customerId: Int?
    var customerName: String?
    var address: String?
    var creditCardInfo: Int?
    var shippingInfo: String?
    
    //initializer
    override init(){
        super.init()
        self.customerId=0
        self.customerName = ""
        self.address=""
        self.creditCardInfo=0
        self.shippingInfo=""
    }
    //parameterized initializer
    init(u_Id: String,c_Id: Int,c_name: String,c_address: String,c_creditCardInfo: Int,c_shippingInfo: String)
    {
        super.init()
        self.customerId = c_Id
        self.customerName = c_name
        self.address = c_address
        self.creditCardInfo = c_creditCardInfo
        self.shippingInfo = c_shippingInfo
    }
    
    func register()
    {
        
    }
    func login()
    {
        
    }
    func update_profile()
    {
        
    }
    
}
