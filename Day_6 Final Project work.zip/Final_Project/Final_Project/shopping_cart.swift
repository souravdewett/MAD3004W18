//
//  shopping_cart.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class shopping_cart : Customer{
    var cardId: Int?
    var productId: Int?
    var quantity: Int?
    var dateAdded: Int?
    
    //default initializer
    override init(){
        super.init()
        self.cardId = 0
        self.productId = 0
        self.quantity = 0
        self.cardId = 0
        
    }
    
    //parameterized initializer of subclass shopping_cart
    init(c_Id: Int,c_name: String,c_address: String,c_creditCardInfo: Int,c_shippingInfo: String,s_cardId: Int,s_productId: Int,s_quantity: Int,s_dateAdded: Int){
        super.init()
        self.cardId = s_cardId
        self.productId = s_productId
        self.quantity = s_quantity
        self.dateAdded = s_dateAdded
    }
    
    func addCartItem(){
        
    }
    
    func updateQuantity(){
        
    }
    
    func viewCartDetails(){
        
    }
    
    func checkOut(){
        
    }
    
}

