//
//  Administrator.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class Administrator: User{
    var adminname: String?
    
    //initializer
    override init() {
        super.init()
        self.adminname = ""
    }
    //parameterized initializer
    init(u_Id: String,adminname: String) {
        super.init()
        self.adminname = adminname
    }
    func updateCatalog()
    {
        
    }
}
