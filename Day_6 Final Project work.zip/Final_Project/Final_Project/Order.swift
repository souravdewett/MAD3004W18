//
//  Order.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class Order : Customer{
    var oderId: Int?
    var dateCreated: String?
    var dateShipped: String?
    var status: String?
    var shippingId: String?
    
    
    //default initializer
    override init() {
        super.init()
        self.oderId = 0
        self.dateCreated = ""
        self.dateShipped = ""
        self.status = ""
        self.shippingId = ""
    }
    
    //parameterized initializer
    init(c_Id: Int,c_name: String,o_orderId: Int,o_dateCreated: String,o_dateShipped: String,o_status: String,o_shippingId: String)
    {
        super.init()
        self.oderId = o_orderId
        self.dateCreated = o_dateCreated
        self.dateShipped = o_dateShipped
        self.status = o_status
        self.shippingId = o_shippingId
        
    }
    
    func placeorder(){
        
    }
}
