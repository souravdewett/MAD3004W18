//
//  Orderdetails.swift
//  Final_Project
//
//  Created by Sourav Dewett on 2018-02-05.
//  Copyright © 2018 Sourav Dewett. All rights reserved.
//

import Foundation
class Orderdetails:Order{
    
    var productID : Int?
    var productName : String?
    var quantity : Int?
    var unitCost : Float?
    var subTotal : Float?
    
    //initializers
    
    override init(){
        super.init()
        self.productID = 0
        self.productName = ""
        self.quantity = 0
        self.unitCost = 0.0
        self.subTotal = 0.0
        
    }
}
