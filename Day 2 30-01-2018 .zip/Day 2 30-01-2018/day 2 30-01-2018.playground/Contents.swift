//: Playground - noun: a place where people can play

import UIKit

var str = "Hello Playground"

print(str)
//use """ for multiple line strings
let strOne = """
This is My macbook
Soon i will buy a windows laptop
Wish i had an alienware one
"""
print(strOne)

var mood = ""
var heart = " \u{1F496}" //using unicode character to print a character
mood = "happy"
if mood.isEmpty         //checking if the mood variable is empty or not
{
    print("Cheer Up!!")
}

else
{
    print(heart)
}
mood += "Cheerful Joyful"
print(mood)

heart += " Be Happy"
print(heart)
var firstName = String()
firstName = "Soura"
print(firstName)

for index in firstName
{
    print(index)
}
let initial: Character = "v"
firstName.append(initial)

print(firstName)
// using index functions to get the length of a variable or to know the first or last charcater
print("FirstName is \(firstName) which is  \(firstName.count) characters long.")
print("start Index",firstName[firstName.startIndex])
//print("end Index:",firstName[firstName.endIndex])
print("before end index", firstName[firstName.index(before: firstName.endIndex)])
print("after start index", firstName[firstName.index(after: firstName.startIndex)])
print("5th Character :", firstName[firstName.index(firstName.startIndex,offsetBy: 4)])
print("3rd from last character:", firstName[firstName.index(firstName.endIndex,offsetBy: -3)])

var idx = firstName.index(firstName.startIndex,offsetBy:3)
print("fourth character:",firstName[idx])

/*
let s = "Cheema"
var len = s.count

for i in 1...len
{
    print(s)
}

*/

//use of insert and remove method in strings...

/*var language = "Swift"
print("language : ",language)

language.insert("!",at:language.endIndex)
print("language : ",language)

language.insert(contentsOf:"Java", at: language.endIndex)
print("language :",language)

language.insert(contentsOf:"is better than", at:language.index(language.startIndex,offsetBy:6))
print("language contentsOf: ",language)

language.remove(at: language.index(before: language.endIndex))
print("language remove : ",language)

let range = language.startIndex..<language.endIndex
language.removeSubrange(range)
print("RemoveSubRange : ",language)

let greeting = "happy Holidays!"
let index
*/
/*
 let greeting = "happy Holidays"
let index = greeting.index(of: " ") ?? greeting.endIndex
let start = greeting[..<index]
let newGreet = String(start)

print("sub string : ",newGreet)
print("string in uppercase : ",newGreet.uppercased())

if(newGreet == newGreet.uppercased())
{
    print("equal")
}
else
{
    print("not equal")
}
var grade :String?
//grade ="A"
let finalGrade = grade ?? "F"

if (finalGrade.isEmpty)
{
    print("Not Graded yet")
}
else
{
    print("Grade : ",finalGrade)
}
*/

