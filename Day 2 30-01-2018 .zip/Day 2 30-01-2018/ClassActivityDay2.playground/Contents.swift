//print name in normal order and reverse order using index
let name = "Cheema"
// Counting Length of string
let strlen = name.count
print("Name Length",strlen)
print("start to end")
// From start to last
for index in 1...6
{
print("Characters are as follows:", name[name.index(name.startIndex, offsetBy: index-1)])
}
// from end index to start
for index in 1...6
{
print("Reverse Characters are as follows:",name[name.index(name.endIndex, offsetBy: -index)])
}
