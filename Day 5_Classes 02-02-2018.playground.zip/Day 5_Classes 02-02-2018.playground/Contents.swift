class Employee {
    
    var empID: Int?
    var empName: String?
    var basicPay: Double?
    
    
    // initializers in swift
    // Default initializer
    init() {
        
        self.empID = 0
        self.empName = "Sourav"
        self.basicPay = 2000
        
    }
    // Parametrized initializer.
    init(ID:Int,name:String,pay:Double) {
        self.empID = ID
        self.empName = name
        self.basicPay = 0.0
    }
    
    
    // deinitializer.
    
    
    func display() {
        
        print("EmployeeID : ", self.empID!)// use of self is to point to its own instances like function,class.
        print("Employee Name: ", self.empName!)
        print("Basic Pay : ", self.basicPay!)
        
    }
    deinit {
        
        print("Employee object deinitialized")
    }
}
var emp1 = Employee()
emp1.empID = 101
emp1.empName = "Cheema"
emp1.basicPay = 5000
emp1.display()
var emp3 = Employee()
emp3.display()
var emp4 = Employee(ID: 104, name: "jane", pay: 3409.89)
emp4.display()

// Inheriting from Employee Class.
class PermanentEmployee : Employee {
    var vacationWeeks: Int?
    
    override init () {
        super.init()
        self.vacationWeeks = 0
    }
    //paraeterized initializer of subclass
    init(eID : Int, enm: String, epay : Double, weeks : Int)
    {
        super.init(ID: eID , name: enm, pay: epay)
        self.vacationWeeks = weeks;
        
    }
}
var obj2 =  PermanentEmployee()
obj2.display()
obj2.empID = 102
obj2.empName = "Cheema"
obj2.basicPay = 3000
obj2.vacationWeeks = 10

var obj5 = PermanentEmployee()
//obj5.display()

var obj6 = PermanentEmployee(eID: 106 , enm : "Navi", epay: 1320.77, weeks: 1)
obj6.display()
