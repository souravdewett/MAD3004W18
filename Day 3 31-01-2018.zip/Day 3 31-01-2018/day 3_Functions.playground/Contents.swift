//: Playground - noun: a place where people can play
// Working with functions
//function declaration

func add()
{
    print("i am in User Defined Function")
}

add()
func add(n1:Int, n2:Int)
{
    var sum : Int
    sum = n1 + n2
    print("sum : ",sum)
}

add(n1:10,n2:20)
//Single Parameter
        func welcome (name:String)
        {
            print("hello, \(name)")
        }

func sub(a:Int, _ b :Int)
{
    let c = a - b
    print("Sub : \(c)")
}

sub(a: 10, 5)

func mul(a:Int, b:Int) -> Int
{

  let  c = a * b
    print("Multiplication is : \(c)")
    return c
}

mul(a:10, b:20)
func swipe(aa: inout Double, bb:inout Double)
{
    //function parameters are constants by default
    /*let temp = aa
    a = b
    b = temp
    return(b,a)
 */

 }

/*var(a,b) = swipe(number1: 10, b: 20)
    print(("a: \(a), b: \(b)")
        (_,c) = swipe(number1: 10, b:20)
        print("c : \(c)")
 */

var x=8.0 ,y = 9.0
swipe(aa:&x, bb: &y)
print("x : \(x), \(y)")

func simpleInterest(amount:Double, noOfYears: Double, rate:Double = 5.0) -> Double
{
    let si = amount * rate * noOfYears / 100
    return si
}

print("simple Interest: \(simpleInterest(amount: 1000, noOfYears: 5))")

func display(n:Int...)
{
    for i in n{
        print(i)
    }
}
display(n: 1,2,3,4,5)
display(n: 20,20,30)

//passing array as parameter
func display(numberValues:Int, parameters: [Int]...)
{
    print("Number of values \(numberValues)")
    for i in parameters
    {
        print("i: \(i)")
    }
}
var arr=[1,2,3,4,5]
display(numberValues:3, parameters:arr,arr,arr)
//sum  of two arrays
func display(arrayList:[Int]...) -> [Int]
{
    var array1 = arrayList[0]
    var array2 = arrayList[1]
    var result = [Int]()

if array1.count == array2.count
{
    for i in 0..<array1.count{
        result.append(array1[i] + array2[i])
    }
    
}
return result
}
var a1 = [1,2,3,4,5]
var a2 = [10,11,12,13,14]
var a3 = display(arrayList:a1,a2)

