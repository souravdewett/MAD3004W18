//: Playground - noun: a place where people can play

import UIKit

//Dictionaries
var nameOfIntegers = [Int: String]() //nameOfIntegers is an empty dictionary

nameOfIntegers[16] = "sixteen"

print("nameOfIntegers : \(nameOfIntegers)")
nameOfIntegers[28] = "twenty Eight"
print("dictionary contains \(nameOfIntegers.count) elements")
print("dictionary : ",nameOfIntegers)
print(",nameOfintegers",nameOfIntegers)

if nameOfIntegers.isEmpty
{
    print("Dictionary is empty")
}
else
{
    print(nameOfIntegers)
}

var airports: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
print("Airports : \(airports)")
print("the airport dictionary contains \(airports.count) items.")

airports["LHR"] = "London Heathrow"
airports["YYZ"] = "TP International"
print("airports : ",airports)
airports["AMD"] = "SVP International"
print("airports :",airports)

let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB")
print("the Old valuefor DUB was \(oldValue)")
//prints the oldvalue for DUB was Dublin

if let airportName = airports["AMD"]
{
    print("The name of the airport is \(airportName).")
}
else
{
    print("That airport is not in the airports dictionary.")
}

airports["Mars"] = "Range Rover" //"Apple International is fictional
print(airports)
airports["Mars"] = nil
print("airports : \(airports)")

if let removedValue = airports.removeValue(forKey: "DUB")
{
    print("The removed airport's name is \(removedValue)")
}
else
{
    print("the airports dictionary does not contain a value for dub")
}// Prints "the removed airport's name is dublin airport."

for(airportCode,airportName) in airports
{
    print(airportCode, airportName)
}

for airportCode in airports.keys
{
    print("Airport Code \(airportCode)")
}

let airportCodes = [String](airports.keys)
print("airportCodes : \(airportCodes)")

let airportnames = [String](airports.values)
print("airport names :\(airportnames)")

var d1 : Dictionary<String, String> = ["India": "hindi","Canada":"English"]
print(d1)
print(d1.description)
print(d1["India"]!)
print(d1["Canada"]!)
print(d1["USA"])
d1["China"] = "Mandarin"
for(k,v) in d1{
    print("\(k) -> \(v)")
}
d1["Canada"] = "French"
var d2 = ["India":"Hindi", "Canada" : "English"]
for(k,v) in d2{
    print("\(k) -> \(v)")
}

var d3 = [String : AnyObject]()
d3["FirstName"] = "Sourav" as AnyObject
d3["LastName"] = "Cheema" as AnyObject
d3["age"] = Int(20) as AnyObject
d3["salary"] = nil
print("d3" ,d3)

//getting as a Key, value pair
for(k,v)in d3{
    print("\(k) -> \(v)")
}

//Declaring tuples
var x = (10, 20 , "Cheema")
print(x.0)
print(x.1)
print(x.2)

let http404 = (404, "Not found")
print(http404)

let (statusCode, statusMessage) = http404
print("statusCode:", statusCode)
print("statusMessage:", statusMessage)

let(codeOnly, _) = http404
print("codeOnly:", codeOnly)

let errorDescription = (Code: 404, statusMessage: "Not Found")
print(errorDescription.Code,errorDescription.statusMessage)



