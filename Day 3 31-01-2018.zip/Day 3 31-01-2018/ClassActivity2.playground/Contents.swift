//: Playground - noun: a place where people can play

// Class Activity for Calling dictionary within another dictionary.
// Creating the Address Dictionary.
var Address = [String: AnyObject]()
Address["Street"] = "265 Yorkland Boulevard" as AnyObject
Address["Area"] = "North York" as AnyObject
Address["PostalCode"] = "M1H1Y1" as AnyObject

// Creating Person Dictionary.
var Person:Dictionary<String, AnyObject> =
    ["First Name" : "Sourav" as AnyObject, "Last Name" : "Cheema" as AnyObject, "Age" : Int(20) as AnyObject, "Address" : Address as AnyObject , "Total Amount" : Int(2000) as AnyObject]
print(Person);
